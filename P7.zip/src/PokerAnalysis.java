import java.util.ArrayList;
import java.util.List;

/**
 * This class implements the PokerAnalyzer interface. It will analyze the List
 * of Cards it is given at construction. Most of the tests will only give 5
 * cards in the List, like real Poker, but some tests will contain more than 5
 * cards. In that case, you have a hand (say, a flush) if ANY 5 of those cards
 * have that hand (flush in this case).
 *
 */
public class PokerAnalysis implements PokerAnalyzer {

	private List<Card> cards; // cards in each hand
	private int[] rankCounts; // w
	private int[] suitCounts;

	/**
	 * The constructor has been partially implemented for you. cards is the
	 * ArrayList where you'll be adding all the cards you're given. In addition,
	 * there are two arrays. You don't necessarily need to use them, but using them
	 * will be extremely helpful.
	 * 
	 * The rankCounts array is of the same length as the number of Ranks. At
	 * position i of the array, keep a count of the number of cards whose
	 * rank.ordinal() equals i.
	 * 
	 * Repeat the same with Suits for suitCounts. For example, if your Cards are
	 * (Clubs 4, Clubs 10, Spades 2), your suitCounts array would be {2, 0, 0, 1}.
	 * 
	 * @param cards the list of cards to be added
	 */
	public PokerAnalysis(List<Card> cards) {
//		CLUBS, DIAMONDS, HEARTS, SPADES
//		  0        1        2       3  
		this.cards = new ArrayList<Card>();
		this.rankCounts = new int[Rank.values().length];
		this.suitCounts = new int[Suit.values().length];
		this.cards = cards;

		for (Card c : cards) { // check if the rank in my count is within 13 and if so increment it
			int rankIndex = c.getRank().ordinal();
			int suitIndex = c.getSuit().ordinal();
			rankCounts[rankIndex] += 1;
			suitCounts[suitIndex] += 1;
		}
	}

	@Override
	public boolean hasPair() {
		// run through list of cards and count if they have the same rank
//		for (int count : rankCounts) {
//			if (count >= 2) {
//				return true;
//			}
//		} 
//		return false;
		
		for (int i = 0; i < rankCounts.length; i++) {
			if (rankCounts[i] >= 2) {
				return true;
			} 
		}
		return false;
	}

	@Override
	public boolean hasThreeOfAKind() {
		/** has three cards with the same rank */
		for (int i = 0; i < rankCounts.length; i++) {
			if (rankCounts[i] >= 3) {
				return true;
			} 
		}
		return false;
	}

	@Override
	public boolean hasTwoPair() {
		/**
		 * there are two different ranks such that there are two cards of each of those
		 * ranks
		 */
		
		int count = 0;
		for (int i = 0; i < rankCounts.length; i++) {
			if (rankCounts[i] >= 2) {
				count += 1;
			} 
		}
		return count >= 2;
	}

	@Override
	public boolean hasFourOfAKind() {
		for (int i = 0; i < rankCounts.length; i++) {
			if (rankCounts[i] >= 4) {
				return true;
			} 
		}
		return false;
	}

	@Override
	public boolean hasFullHouse() {
		boolean two = false;
		boolean three = false;
		for(int i = 0; i < rankCounts.length; i++) {
			if (rankCounts[i] >= 3) {
				three = true;
			} else if (rankCounts[i] >= 2) {
				two = true;
			}
		}
		return two && three;
	}

	/**
	 * You don't need to implement this, but it will be helpful. This method returns
	 * true if there is a straight hand starting with the Rank r and false
	 * otherwise. As the Wikipedia page says, no straight hand can start with a
	 * Jack, Queen or King. Also look into the nextRank() method of the Rank enum.
	 */
	private boolean hasStraight(Rank r) {
		return !(r == Rank.JACK || r == Rank.QUEEN || r == Rank.KING);
	}

	@Override
	public boolean hasStraight() {
//		sort cards before we check the ranks
		cards.sort(new CardComparator(false));
		
		if (cards.size() == 0 || hasStraight(cards.get(0).getRank()) == false) {
			return false;
		}
		
		for(int i = 0; i < cards.size() - 1; i++) {
			Card currCard = cards.get(i);
			Card nextCard = cards.get(i + 1);
			if (currCard.getRank().nextRank() != nextCard.getRank()) {
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean hasFlush() {
		for(int count : suitCounts) {
			// [0, 0, 0, 0]
			if (count >= 5) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Private helper similar to hasStraight(Rank r), but this time you consider
	 * suit also. Optional, but very helpful to write.
	 */
	private boolean hasStraightFlush(Rank r, Suit s) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean hasStraightFlush() {
		if (hasStraight() == false) {
			return false;
		}
		Suit s = cards.get(0).getSuit();
		for(int i = 0; i < cards.size() - 1; i++) {
			Card currCard = cards.get(i);
			Card nextCard = cards.get(i + 1);
			
			if (currCard.getRank().nextRank() != nextCard.getRank() || 
					currCard.getSuit() != s || nextCard.getSuit() != s) {
				return false;
			}
		}
		return true;
	}

	// My custom methods for testing

	public int[] getRankCounts() {
		return rankCounts;
	}

	public int[] getSuitCounts() {
		return suitCounts;
	}

}
