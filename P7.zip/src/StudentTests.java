import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import org.junit.Test;

public class StudentTests {

	@Test
	public void testDemo() {
//		CLUBS, DIAMONDS, HEARTS, SPADES
		List<Card> cards = new ArrayList<>();
		cards.add(new Card(Rank.ACE, Suit.CLUBS));
		cards.add(new Card(Rank.ACE, Suit.HEARTS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
	
		PokerAnalysis p = new PokerAnalysis(cards);
		
		// Check that suits array is updated correctly
		int[] answer1 = {2, 0, 1, 0};
		assertTrue(Arrays.equals(p.getSuitCounts(), answer1));
		
		// check that rank array is updated correctly
		int[] answer2 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 2};
		assertTrue(Arrays.equals(p.getRankCounts(), answer2));
	}
	
	@Test
	public void testHasPair1() {
//		CLUBS, DIAMONDS, HEARTS, SPADES
		List<Card> cards = new ArrayList<>();
		cards.add(new Card(Rank.ACE, Suit.CLUBS));
		cards.add(new Card(Rank.ACE, Suit.HEARTS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
	
		PokerAnalysis p = new PokerAnalysis(cards);
		// assertTrue is based on a single boolean condition
		assertTrue(p.hasPair() == true);
	}
	
	@Test
	public void testHasPair2() {
//		CLUBS, DIAMONDS, HEARTS, SPADES
		List<Card> cards = new ArrayList<>();
		cards.add(new Card(Rank.ACE, Suit.CLUBS));
		cards.add(new Card(Rank.KING, Suit.HEARTS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
	
		PokerAnalysis p = new PokerAnalysis(cards);
		// assertTrue is based on a single boolean condition
		assertTrue(p.hasPair() == false);
	}
	
	@Test
	public void testHas2Pair2() {
//		CLUBS, DIAMONDS, HEARTS, SPADES
		List<Card> cards = new ArrayList<>();
		cards.add(new Card(Rank.ACE, Suit.CLUBS));
		cards.add(new Card(Rank.KING, Suit.HEARTS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
		cards.add(new Card(Rank.KING, Suit.HEARTS));
		PokerAnalysis p = new PokerAnalysis(cards);
		// assertTrue is based on a single boolean condition
		assertTrue(p.hasTwoPair() == true);
	}
	
	@Test
	public void testHas4Pair() {
//		CLUBS, DIAMONDS, HEARTS, SPADES
		List<Card> cards = new ArrayList<>();
		cards.add(new Card(Rank.ACE, Suit.CLUBS));
		cards.add(new Card(Rank.ACE, Suit.HEARTS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
		cards.add(new Card(Rank.JACK, Suit.CLUBS));
		PokerAnalysis p = new PokerAnalysis(cards);
		// assertTrue is based on a single boolean condition
		assertTrue(p.hasFourOfAKind() == true);
	}
	
	@Test
	public void testRank() {
//		CLUBS, DIAMONDS, HEARTS, SPADES
		Rank r = Rank.ACE;
		
		System.out.println(r == Rank.ACE);
		
	}
}
